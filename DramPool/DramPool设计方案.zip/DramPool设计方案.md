# DramPool设计方案

# 1 DramPool架构

![](attachment/1.webp)

# 2 DramPool进程初始化

在拉起推理服务之前，需要在每个计算节点上拉起UCM池化的独立进程（DramPool），用来管理和共享本地Dram空间，涉及到的关键参数包括：

* \--addr \:\   服务地址，供DramStore建立连接进行控制信息交换。
* \--nics \…   指定用来执行RDMA的NICs（例如 mlx5\_0, mlx5\_0 mlx5\_1），DramPool中所有的Pinned Memory都会注册到这些NIC上，供RDMA访问。
* \--pool-size-gb \   当前节点上为池化贡献的DRAM内存大小，单位GB
* \--kvcache-block-sizes \…    池化不支持变长能力，只支持定长块，但支持可配置多个不同的定长块。
* \--kvcache-block-proportions \…    不同块长占用池化内存容量的比例，默认是均分，即1：1
* \--ttl-minutes \   block在池化中的绝对存活时间，单位分钟，默认值120

​

```
 main()
  │
  ├─[1] 参数解析            DramPoolConfig::Parse(argc,argv)  (--addr/--nics/--pool-size-gb/
  │                                                --kvcache-block-sizes/--kvcache-block-proportions/
  │                                                --ttl-minutes/--worker-threads/--recv-queue-depth)
  │
  ├─[2] 内存申请            每个 block-size 一个 BufferManager 实例（slot_capacity=块长）。
  │                        for each block-size:
  │                           dataPool_[i].Init("dataPool_"+i, HOST_PINNED, block_size_i, slot_num_i)
  │
  ├─[3] 元数据初始化        meta_.Init()
  │
  ├─[4] 启动传输服务        transport_.Init(localEndpoint)
  │                         transport_.RegisterRegion(dataPool_)
  │                         transport_.InstallTransport(<协议>)                       
  │
  ├─[5] 启动shardExecutor线程
  │           
  ├─[6] 启动completionPoller线程 
  │                              
  ├─[7] 启动监听服务        transport_.Listen(localEndpoint)                         
  │                         transport_.SetRecvHandler([this](buf,len,client){ recv_.OnRecv(...); })
  │                         workers_.Start(config_.workerThreads)
  │                        主线程进入监听循环
  │
  └─[8] Final              SIGTERM/SIGINT → Shutdown()
                           
```

关停：

```
 Shutdown(): stop_accept → 停 Recv → 清理request_queue，completion_queue
            → 停 shardExecutor线程，completionPoller线程
            → transport_.Shutdown() → meta_.Clear → BufferMgr 析构 → 退出
```

​

# 3 接收报文格式

Dump

请求报文格式：

```cpp
uint8_t opcode;
uint64_t resp_addr;//flag buffer
uint64_t ttl; // 请求级别的过期时间
uint16_t batch_size;
[
  std::array<bytes, 16> key;
  uint64_t addr;
  uint32_t len;
  uint32_t idx; // 绝对位置
]
```

返回报文格式：

```cpp
uint32_t errcode; // 0 ok
uint32_t errcode; // 0 ok
.
```

Load

```cpp
uint8_t opcode;
uint64_t resp_addr;//flag buffer
uint16_t batch_size;
[
  std::array<bytes, 16> key;
  uint64_t addr;
  uint32_t len;
  uint32_t idx;
]
```

​

Lookup

```cpp
uint8_t opcode;
uint64_t resp_addr;
uint16_t batch_size；
[
  std::array<bytes, 16> key;
  std::array<bytes, 16> key;
...
]
```

返回报文格式：

**==idx表示命中最长前缀key个数，非命中最长前缀下标==**

```cpp
uint32_t idx; // 0 ok
```

# 4 元数据

节点间存储的每条KVCache数据包含：键、值、在推理请求中的绝对位置、到期时间。所有信息都是在写入时确定，此后不再发生变化。节点内维护三套索引信息来支持对应场景：

## 4.1 主索引

按键组织，用于快速定位某个KVCache数据是否存在及其内容。

1）每条KVCache数据元信息：Entry

```cpp
using BlockKey = std::array<std::byte, 16>;

enum class EntryState : uint8_t {
    RESERVED = 0,  // 已占位，尚未开始或尚未完成写入
    READY    = 1,  // 数据完整，可 lookup/load 命中
};

class KvBufferHandle {
    // BufferMgr 返回的本地池化内存信息。
    uint32_t buffer_mgr_id{0};
    uint64_t local_addr{0};
    uint32_t length{0};
}

class Entry {
    BlockKey key;

    KvBufferHandle kv_buffer_handle;

    // 绝对地址，dump协议字段idx。
    uint32_t abs_pos{0};

    // 过期时间
    uint64_t expire_time{0};
    uint64_t lease_time{0}; //gc使用

    // 状态字段。只有 READY 对 lookup/load 可见。
    EntryState state{EntryState::RESERVED};

    // GC的entry需要满足refcnt==0
    uint32_t refcnt{0};
    Status status; // gc使用

    // Intrusive-like index handles.
    ExpireIndex::iterator expire_it; // entry 在到期时间索引的iterator
    PositionIndex::iterator position_it;
};
```

​

2）索引数据结构

① 主索引拥有 Entry 生命周期。

**==② 在Entry析构时，释放对应kvcache BufferManager的内存。(5.1.2 待讨论)==**

```cpp
using PrimaryIndex =
    std::unordered_map<BlockKey, std::unique_ptr<Entry>, BlockKeyHasher>;
```

​

3）引用

Entry结构体定义中的 `expire_it` 和 `position_it` 是 Entry 在到期时间、绝对位置索引里的准确位置，以便删除时可以直接通过 iterator 级联删除

## 4.2 到期时间索引

按到期时间升序排列，用于从最早到期的一端顺序扫描过期条目。

到期时间索引：只保存 `Entry*` ，不拥有对象。用于快速找到全局最早过期的 entry：expire\_index.begin();&#x20;

```cpp
using ExpireIndex = std::multimap<uint64_t, Entry*>;

```

​

## 4.3 绝对位置索引

按绝对位置升序排列，相同绝对位置的数据比较其到期时间，用于从绝对位置一端快速选取淘汰目标。

```cpp
struct PositionKey {
    uint32_t abs_pos;
    uint64_t expire_time;
};

struct PositionKeyLess {
    bool operator()(const PositionKey& a, const PositionKey& b) const
    {
        if (a.abs_pos != b.abs_pos) {
            return a.abs_pos < b.abs_pos;
        }
        return a.expire_time < b.expire_time;
    }
};

using PositionIndex = std::multimap<PositionKey, Entry*, PositionKeyLess>;
```

​

## 4.4 拆分shard

元数据分为多个shard存储，使用key%shard\_count路由到对应的shard，以减少访问元数据时的锁冲突

```cpp
class MetadataIndexShard {
private:
    mutable std::shared_mutex mu_; // 保护三套全局索引

    PrimaryIndex primary_index_;
    ExpireIndex expire_index_;
    PositionIndex position_index_;
};
```

#

# 5 整体流程

## 5.1 Dump流程

### 5.1.1 流程图

###

![](attachment/2.webp)

系统拆成三个角色：

1. Receiver:    只负责 receive + KvProtocol 解包 + 根据key路由 task到shard
2. ShardExecutor:    负责调用BufferMgr分配内存，操作元数据和 TransportMgr submit
3. CompletionPoller:    只负责轮询transportMgr任务处理状态，拿到完成事件后投递 completion event

​

### 5.1.2 异常处理

1）异常处理

* 失败

① BufferMgr分配失败-》调用transport写回失败状态到 flagbuffer

② MetadataIndex插入reserve entry失败-》释放buffer，调用transport写回失败状态到 flagbuffer

③ TransportMgr submit 失败-》删除 primary / expire / position（entry析构时释放buffer），调用transport写回失败状态到 flagbuffer

​

* Timeout

**==待考虑方案：transport请求超时后，无法停止RDMA任务，后续会写脏数据。==**（drampool的buffer可隔离，dramstore如何隔离？）

timeout 只是“本轮等待超时”，但 RDMA 仍在飞，且无法终止

删除或失效元数据，同时将 buffer 隔离，避免被复用后被迟到 RDMA 覆盖。buffer若按照隔离的方案，就不能在Entry析构时释放。

迟到 completion 到来时，ShardExecutor会根据 key/generation 判断为 stale completion 并忽略。

####

2）generation

**==待决策：若超时场景不删除，一直保持，则无需generation。==**

用于防 stale completion / ABA-like 场景：

DramPoolServer 进程级 std::atomic\ global\_generation，每次使用时自增。

```text
1. 老 Entry 因超时被删除。
2. 同 key 新 DUMP 请求到来，创建新 Entry，赋值新的global_generation。
3. 老 handle 的 transport handle completion 晚到。
4. CompletionPoller 通过 generation mismatch 识别它是旧 completion，不能把新 Entry 置 READY。
```

​

### 5.1.3 两种线程分配方案

1. 独立线程

1）Receiver: 1 个或多个独立线程

2）CompletionPoller: 1 个或多个独立线程

3）GC: 1 个独立线程

4）ShardExecutor: 每个shard 1个线程，若shard多可一组shard一个线程

​

2. 统一 WorkerPool

多级优先级队列：completion 最高优先级，第二优先级receiver，第三优先级shardExecutor，gc最低优先级

​

## 5.2 load流程

### 5.2.1 流程图

​

![](attachment/3.webp)

### 5.2.2 线程及任务队列

**==待决策：dump及load的completionPoller队列和线程可选方案：==**

| **方案**                      | **结构**                                                        | **优点**                                | **缺点**                                                                 | **适用场景**                      |
| --------------------------- | ------------------------------------------------------------- | ------------------------------------- | ---------------------------------------------------------------------- | ----------------------------- |
| 一个CompletionPoller线程 + 两个队列 | 一个线程同时轮询 `dump_pending_queue` 和 `load_pending_queue`，可设置调度比例  | DUMP/LOAD 队列隔离；可以优先处理 load            | DUMP 发布仍会慢                                                             | LOAD QPS 较高，且 DUMP READY 延迟敏感 |
| 两个CompletionPoller 线程+ 两个队列 | `DumpCompletionPoller` 处理 DUMP，`LoadCompletionPoller` 处理 LOAD | DUMP/LOAD 完全隔离；LOAD 很多不会影响 DUMP READY | 线程和生命周期管理复杂度增加。MetadataIndex 锁竞争更强；TransportMgr `QueryStatus` 需要支持多线程； | 测出一个 Poller 成瓶颈               |

## 5.3 lookup流程

##

​

![](attachment/4.webp)

​

**==待决策：==**

**==1) LookupExecutor依次访问全部key对应shard的元数据。是否需要并行访问key（lookup无需RDMA只查key较快）？==**

**==2）若采用LookupExecutor使用几个线程 ==**

Receiver

-> 把整个 LookupRequest 发给一个 LookupExecutor

LookupExecutor

-> 按请求顺序逐个 key 路由到对应 shard，查询key，每次只持有该shard的读锁

-> 遇到第一个 miss/reserved/expired 就停止

-> 得到 prefix\_hit\_count

-> 提交 flagbuffer(prefix\_hit\_count)

​
