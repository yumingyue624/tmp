# DramPool设计方案

# 1 DramPool架构

​[~https://excalidraw.com/#json=p7EMLzf0gDMRjWfnIvNPS,bhV7LEJnB7JDbJ-ceiLu0A~](https://excalidraw.com/#json=p7EMLzf0gDMRjWfnIvNPS,bhV7LEJnB7JDbJ-ceiLu0A)​

![](attachment/1.webp)

# 2 DramPool进程初始化

在拉起推理服务之前，需要在每个计算节点上拉起UCM池化的独立进程（DramPool），用来管理和共享本地Dram空间，涉及到的关键参数包括：

* \--addr \:\   服务地址，供DramStore建立连接进行控制信息交换。
* \--nics \…   指定用来执行RDMA的NICs（例如 mlx5\_0, mlx5\_0 mlx5\_1），DramPool中所有的Pinned Memory都会注册到这些NIC上，供RDMA访问。
* \--pool-size-gb \   当前节点上为池化贡献的DRAM内存大小，单位GB
* \--kvcache-block-sizes \…    池化不支持变长能力，只支持定长块，但支持可配置多个不同的定长块。
* \--kvcache-block-proportions \…    不同块长占用池化内存容量的比例，默认是均分，即1：1
* \--ttl-minutes \   block在池化中的绝对存活时间，单位分钟，默认值120

​

```
 main()
  │
  ├─[1] 参数解析            DramPoolConfig::Parse(argc,argv)  (--addr/--nics/--pool-size-gb/
  │                                                --kvcache-block-sizes/--kvcache-block-proportions/
  │                                                --ttl-minutes/--worker-threads/--recv-queue-depth)
  │
  ├─[2] 内存申请            每个 block-size 一个 BufferManager 实例（slot_capacity=块长）。
  │                        for each block-size:
  │                           dataPool_[i].Init("dataPool_"+i, HOST_PINNED, block_size_i, slot_num_i)
  │
  ├─[3] 元数据初始化        meta_.Init()
  │
  ├─[4] 启动传输服务        transport_.Init(localEndpoint)
  │                         transport_.RegisterRegion(dataPool_)
  │                         transport_.InstallTransport(<协议>)                       
  │
  ├─[5] 启动taskflow线程(待讨论)  
  │           
  ├─[6] 启动completionPoller线程(待讨论)  
  │                              
  ├─[7] 启动监听服务        transport_.Listen(localEndpoint)                         
  │                         transport_.SetRecvHandler([this](buf,len,client){ recv_.OnRecv(...); })
  │                         workers_.Start(config_.workerThreads)
  │                        主线程进入监听循环
  │
  └─[8] Final              SIGTERM/SIGINT → Shutdown()
                           
```

关停：

```
 Shutdown(): stop_accept → 停 Recv → 清理TaskQueue → 停 TaskWorkerPool
            → transport_.Shutdown() → meta_.Clear → BufferMgr 析构 → 退出
```

​

# 3 接收报文格式

Dump

```cpp
uint8_t opcode;
uint64_t resp_addr;//flag buffer
uint64_t ttl; // 请求级别的过期时间
uint16_t batch_size;
[
  std::array<bytes, 16> key;
  uint64_t addr;
  uint32_t len;
  uint32_t idx; // 绝对位置
]
```

Load

```cpp
uint8_t opcode;
uint64_t resp_addr;//flag buffer
uint16_t batch_size;
[
  std::array<bytes, 16> key;
  uint64_t addr;
  uint32_t len;
  uint32_t idx;
]
```

Lookup

```cpp
uint8_t opcode;
uint64_t resp_addr;
uint16_t batch_size；
[
  std::array<bytes, 16> key;
  std::array<bytes, 16> key;
...
]
```

#

# 4 元数据

## 4.1 元数据定义

节点间存储的每条KVCache数据包含：键、值、在推理请求中的绝对位置、到期时间。所有信息都是在写入时确定，此后不再发生变化。节点内维护三套索引信息来支持对应场景：

* 主索引：按键组织，用于快速定位某个KVCache数据是否存在及其内容。
* 到期时间索引：按到期时间升序排列，用于从最早到期的一端顺序扫描过期条目。
* 绝对位置索引：按绝对位置升序排列，相同绝对位置的数据比较其到期时间，用于从绝对位置一端快速选取淘汰目标。

三套索引指向同一批数据实体，由于KVCache在写入后不再更新，所以索引只需要处理两种操作：新增和删除。

## 4.2 数据结构

1）每条KVCache数据元信息：Entry

```cpp
using BlockKey = std::array<std::byte, 16>;

enum class EntryState : uint8_t {
    RESERVED = 0,  // 已占位，尚未开始或尚未完成写入
    READY    = 1,  // 数据完整，可 lookup/load 命中
};

struct Entry {
    BlockKey key;

    // BufferMgr 返回的本地池化内存信息。
    uint32_t buffer_mgr_id{0};
    uint64_t local_addr{0};
    uint32_t length{0};

    // 绝对地址，dump协议字段idx。
    uint32_t abs_pos{0};

    // 过期时间
    uint64_t expire_at_ms{0};

    // 状态字段。只有 READY 对 lookup/load 可见。
    EntryState state{EntryState::RESERVED};

    // GC的entry需要满足refcnt==0
    uint32_t refcnt{0};

    // Intrusive-like index handles.
    // 只要 Entry 存在，这两个 iterator 就必须有效。
    ExpireIndex::iterator expire_it; // entry 在到期时间索引的iterator
    PositionIndex::iterator position_it;
};
```

​

2）索引数据结构

主索引：主索引拥有 Entry 生命周期。

```cpp
using PrimaryIndex =
    std::unordered_map<BlockKey, std::unique_ptr<Entry>, BlockKeyHasher>;
```

到期时间索引：只保存 `Entry*` ，不拥有对象。用于快速找到全局最早过期的 entry：expire\_index.begin();&#x20;

```cpp
using ExpireIndex = std::multimap<uint64_t, Entry*>;

```

绝对位置索引：

```cpp
struct PositionKey {
    uint32_t abs_pos;
    uint64_t expire_at_ms;
};

struct PositionKeyLess {
    bool operator()(const PositionKey& a, const PositionKey& b) const
    {
        if (a.abs_pos != b.abs_pos) {
            return a.abs_pos < b.abs_pos;
        }
        return a.expire_at_ms < b.expire_at_ms;
    }
};

using PositionIndex = std::multimap<PositionKey, Entry*, PositionKeyLess>;
```

Entry结构体定义中的 `expire_it` 和 `position_it` 是 Entry 在到期时间、绝对位置索引里的准确位置，以便删除时可以直接通过 iterator 删除

MetadataIndex：

```cpp
class MetadataIndex {
private:
    mutable std::shared_mutex mu_; // 保护三套全局索引

    PrimaryIndex primary_index_;
    ExpireIndex expire_index_;
    PositionIndex position_index_;
};
```

#

# 5 整体流程

单线程task处理/多线程task处理待讨论

​

## 5.1 Dump流程

### 5.1.1 流程图

​[~https://excalidraw.com/#json=xYMvXtP9WOFdR7EtRuisP,O6T5BgfMCM5C7zmtSnspRQ~](https://excalidraw.com/#json=xYMvXtP9WOFdR7EtRuisP,O6T5BgfMCM5C7zmtSnspRQ)​

![](attachment/2.webp)

### 5.1.2 组件职责

`DramPoolServer` 是 DramPool 进程的主流程，负责模块初始化、请求接收、任务提交和线程生命周期管理。它内部主要串联以下模块：

* `KvProtocol`：负责解析 DramStore 发来的请求 buffer。
* `TaskFlow`：单线程任务处理逻辑，负责执行 DUMP task 的主流程，包括调用BufferMgr分配内存、调用MetadataIndex创建元信息、调用TransportMgr提交传输、注册 completion。
* `BufferMgr`：负责分配和释放 DramPool 本地 KVCache buffer。
* `MetadataIndex`：负责 `Entry` 生命周期和三套索引维护，包括 `primary_index`、`expire_index`、`position_index`。
* `TransportMgr`：负责提交单边写 KVCache 和单边写 flagbuffer 操作。
* `CompletionPoller`：独立线程，轮询 `TransportMgr` 返回的 async handle，并驱动 `Entry` 从 `RESERVED` 发布为 `READY`。

##

### 5.1.3 组件详细设计

#### 5.1.3.1 taskFlow

taskFlow负责串联任务处理的整体流程：

```text
TaskFlow:
  dequeue DumpTaskContext

TaskFlow -> BufferMgr:
  分配 KVCache buffer

TaskFlow -> MetadataIndex:
  构造 Entry(state=RESERVED)
  插入 primary_index / expire_index / position_index

TaskFlow -> TransportMgr:
  提交单边写 KVCache 数据
  获取 async handle

TaskFlow -> TransportMgr:
  提交单边写 flagbuffer

TaskFlow -> CompletionPoller:
  Register InflightRecord(key, TransportHandle, BufferHandle, generation)
```

`RESERVED` 的含义是 entry 不能被 lookup/load 命中。只有 `CompletionPoller` 确认 KVCache data handle 完成后，才能发布为 `READY`。

​

#### 5.1.3.2 MetadataIndex

1）锁

所有会修改 Entry 或索引的操作必须持有写锁：

```text
Insert primary / expire / position Reserve Entry
MarkReady(Entry)
Remove / timeout cleanup
GC evict
```

load 因为需要使用kvbuffer，需要在写锁内增加refcnt释放锁后提交 RDMA。

lookup 是只读路径持有读锁。

2）Entry 状态与 Ready发布

* Entry 状态：

```cpp
enum class EntryState : uint8_t {
    RESERVED = 0,
    READY = 1,
};
```

* generation

用于防 stale completion / ABA-like 场景：

DramPoolServer 进程级 std::atomic\ global\_generation，每次使用时自增。

```text
1. 老 Entry 因超时被删除。
2. 同 key 新 DUMP 请求到来，创建新 Entry，赋值新的global_generation。
3. 老 handle 的 transport handle completion 晚到。
4. CompletionPoller 通过 generation mismatch 识别它是旧 completion，不能把新 Entry 置 READY。
```

* DUMP 的可见性

以 Entry 状态为准：flagbuffer 的作用是通知 DramStore 本次 DUMP 请求完成；它不直接决定 DramPool 本地 lookup/load 的可见性。DramPool 本地可见性由 CompletionPoller -> MetadataIndex.MarkReady 发布。

```text
RESERVED:
  key 已占位，防止重复 DUMP。
  lookup/load 不命中。

READY:
  KVCache data 已经完成，lookup/load 可命中。
```

3）异常处理

* Submit 失败

如果 BufferMgr 分配成功，但 MetadataIndex reserve entry或 TransportMgr submit 失败，需要回滚：

```text
删除 primary / expire / position
释放 buffer
调用transport写回失败状态到 flagbuffer
```

* QueryStatus 失败

如果 `QueryStatus(handle)` 返回transport传输kvcache失败，移除对应 `Entry`：

```text
MetadataIndex.Remove(key, generation)
BufferMgr.Free(buffer)
TransportMgr.ReleaseHandle(handle)
```

如果失败语义不能保证底层 DMA 已停止，不能立即复用 buffer，应放入 quarantine，等待 TransportMgr 给出 terminal completion 或 abort guarantee 后再释放。

* Timeout

Timeout 需要确认：

* 如果 TransportMgr 明确保证 timeout 后操作已终止，不会再写本地 buffer，可以删除元数据并释放 buffer。

如果 timeout 只是“本轮等待超时”，但 RDMA 可能仍在飞，应删除或失效元数据，同时将 buffer 隔离，避免被复用后被迟到 DMA 覆盖。

迟到 completion 到来时，CompletionPoller 会根据 key/generation 判断为 stale completion 并忽略。

​

#### 5.1.3.3 CompletionPoller

1）任务结构

CompletionPoller 是独立线程，维护一个 pending queue。

```cpp
enum class InflightOpType {
    DUMP,
    LOAD,
};
struct InflightRecord {
    InflightOpType op_type;
    Key key;
    uint64_t generation; // 用于该任务成功完成后，更新索引前比较是否是同一个key，避免ABA-like问题
    TransportHandle handle; // 待轮询的任务，通过该handle去transport查询任务状态：waiting/success/failed
    BufferHandle buffer; // RDMA写入失败了，通过BufferHandle释放对应的kvcache内存
    uint64_t submit_ms; // 预留字段等待时间超长返回失败
};
```

不同返回结果的处理

```cpp
if status == SUCCESS:
      MetadataIndex.MarkReady(key, generation);
      TransportMgr.Release(handle);
      // buffer 继续归 Entry 持有
      
if status == FAILED:
      MetadataIndex.Remove(key, generation);
      BufferMgr.Free(buffer);        // 需要 BufferHandle释放kvcache内存
      TransportMgr.Release(handle);
```

2\) Pending Queue

pending queue存在两个写入方：

TaskFlow 新提交的 handle 会追加到队尾；如果 Poller 查询到队头 handle 还未完成，也会把它重新追加到队尾。

使用 `std::mutex + std::deque<InflightRecord>`：

```cpp
class CompletionPoller {
private:
    std::mutex pending_mu_;
    std::deque<InflightRecord> pending_;
};
```

队列锁只保护 `pop_front` 和 `push_back` 。在锁外查询任务状态`TransportMgr.QueryStatus()`，以保证仅短时间持有锁。由于std::deque非线程安全容器，只做 tail CAS 不能保证正确性，暂不考虑用无锁方案。

```text
lock pending_mu
  pop_front
unlock

QueryStatus(handle)

lock pending_mu
  if WAITING: push_back
unlock
```

​

## 5.2 load流程

### 5.2.1 流程图

​

![](attachment/3.webp)

### 5.2.2 线程及任务队列

队列和线程组织有三种可选方案：

| **方案**                       | **结构**                                                                       | **优点**                                                    | **缺点**                                                                 | **适用场景**                      |
| ---------------------------- | ---------------------------------------------------------------------------- | --------------------------------------------------------- | ---------------------------------------------------------------------- | ----------------------------- |
| 一个 CompletionPoller + 一个合并队列 | `DUMP` 和 `LOAD` 的 `InflightRecord` 放进同一个 `pending_queue`，通过 `op_type` 区分处理逻辑 | 实现最简单；线程少；队列锁简单；TransportMgr 查询路径统一；MetadataIndex 并发压力最低  | LOAD 很多时可能拖慢 DUMP 的 `RESERVED -> READY`；                               | 简单实现                          |
| 一个 CompletionPoller + 两个队列   | 一个线程同时轮询 `dump_pending_queue` 和 `load_pending_queue`，可设置调度比例                 | DUMP/LOAD 队列隔离；可以优先处理 DUMP，降低 READY 发布延迟；仍然只有一个 Poller 线程 | 调度策略更复杂；如果偏向 DUMP，LOAD 的 `refcnt--` 可能变慢；如果偏向 LOAD，DUMP 发布仍会慢          | LOAD QPS 较高，且 DUMP READY 延迟敏感 |
| 两个 CompletionPoller + 两个队列   | `DumpCompletionPoller` 处理 DUMP，`LoadCompletionPoller` 处理 LOAD                | DUMP/LOAD 完全隔离；LOAD 很多不会影响 DUMP READY                     | 线程和生命周期管理复杂度增加。MetadataIndex 锁竞争更强；TransportMgr `QueryStatus` 需要支持多线程； | 测出一个 Poller 成瓶颈               |

## 5.3 lookup流程

![](attachment/4.webp)

​

​

​
