# DramPool设计方案

# 1 DramPool架构

​[~https://excalidraw.com/#json=p7EMLzf0gDMRjWfnIvNPS,bhV7LEJnB7JDbJ-ceiLu0A~](https://excalidraw.com/#json=p7EMLzf0gDMRjWfnIvNPS,bhV7LEJnB7JDbJ-ceiLu0A)​

![](attachment/1.webp)

# 2 DramPool进程初始化

在拉起推理服务之前，需要在每个计算节点上拉起UCM池化的独立进程（DramPool），用来管理和共享本地Dram空间，涉及到的关键参数包括：

* \--addr \:\   服务地址，供DramStore建立连接进行控制信息交换。
* \--nics \…   指定用来执行RDMA的NICs（例如 mlx5\_0, mlx5\_0 mlx5\_1），DramPool中所有的Pinned Memory都会注册到这些NIC上，供RDMA访问。
* \--pool-size-gb \   当前节点上为池化贡献的DRAM内存大小，单位GB
* \--kvcache-block-sizes \…    池化不支持变长能力，只支持定长块，但支持可配置多个不同的定长块。
* \--kvcache-block-proportions \…    不同块长占用池化内存容量的比例，默认是均分，即1：1
* \--ttl-minutes \   block在池化中的绝对存活时间，单位分钟，默认值120

​

```
 main()
  │
  ├─[1] 参数解析            DramPoolConfig::Parse(argc,argv)  (--addr/--nics/--pool-size-gb/
  │                                                --kvcache-block-sizes/--kvcache-block-proportions/
  │                                                --ttl-minutes/--worker-threads/--recv-queue-depth)
  │
  ├─[2] 内存申请            每个 block-size 一个 BufferManager 实例（slot_capacity=块长）。
  │                        for each block-size:
  │                           dataPool_[i].Init("dataPool_"+i, HOST_PINNED, block_size_i, slot_num_i)
  │
  ├─[3] 元数据初始化        meta_.Init()
  │
  ├─[4] 启动传输服务        transport_.Init(localEndpoint)
  │                         transport_.RegisterRegion(dataPool_)
  │                         transport_.InstallTransport(<协议>)                       
  │
  ├─[5] 启动taskflow线程(待讨论)  
  │           
  ├─[6] 启动completionPoller线程(待讨论)  
  │                              
  ├─[7] 启动监听服务        transport_.Listen(localEndpoint)                         
  │                         transport_.SetRecvHandler([this](buf,len,client){ recv_.OnRecv(...); })
  │                         workers_.Start(config_.workerThreads)
  │                        主线程进入监听循环
  │
  └─[8] Final              SIGTERM/SIGINT → Shutdown()
                           
```

关停：

```
 Shutdown(): stop_accept → 停 Recv → 清理TaskQueue → 停 TaskWorkerPool
            → transport_.Shutdown() → meta_.Clear → BufferMgr 析构 → 退出
```

​

# 3 接收报文格式

Dump

```cpp
uint8_t opcode;
uint64_t resp_addr;//flag buffer
uint64_t ttl; // 请求级别的过期时间
uint16_t batch_size;
[
  std::array<bytes, 16> key;
  uint64_t addr;
  uint32_t len;
  uint32_t idx; // 绝对位置
]
```

Load

```cpp
uint8_t opcode;
uint64_t resp_addr;//flag buffer
uint16_t batch_size;
[
  std::array<bytes, 16> key;
  uint64_t addr;
  uint32_t len;
  uint32_t idx;
]
```

Lookup

```cpp
uint8_t opcode;
uint64_t resp_addr;
uint16_t batch_size；
[
  std::array<bytes, 16> key;
  std::array<bytes, 16> key;
...
]
```

#

# 4 元数据

## 4.1 元数据定义

节点间存储的每条KVCache数据包含：键、值、在推理请求中的绝对位置、到期时间。所有信息都是在写入时确定，此后不再发生变化。节点内维护三套索引信息来支持对应场景：

* 主索引：按键组织，用于快速定位某个KVCache数据是否存在及其内容。
* 到期时间索引：按到期时间升序排列，用于从最早到期的一端顺序扫描过期条目。
* 绝对位置索引：按绝对位置升序排列，相同绝对位置的数据比较其到期时间，用于从绝对位置一端快速选取淘汰目标。

三套索引指向同一批数据实体，由于KVCache在写入后不再更新，所以索引只需要处理两种操作：新增和删除。

## 4.2 数据结构

1）每条KVCache数据元信息：Entry

```cpp
using BlockKey = std::array<std::byte, 16>;

enum class EntryState : uint8_t {
    RESERVED = 0,  // 已占位，尚未开始或尚未完成写入
    READY    = 1,  // 数据完整，可 lookup/load 命中
};

struct Entry {
    BlockKey key;

    // BufferMgr 返回的本地池化内存信息。
    uint32_t buffer_mgr_id{0};
    uint64_t local_addr{0};
    uint32_t length{0};

    // 绝对地址，dump协议字段idx。
    uint32_t abs_pos{0};

    // 过期时间
    uint64_t expire_at_ms{0};

    // 状态字段。只有 READY 对 lookup/load 可见。
    EntryState state{EntryState::RESERVED};

    // GC的entry需要满足refcnt==0
    uint32_t refcnt{0};

    // Intrusive-like index handles.
    // 只要 Entry 存在，这两个 iterator 就必须有效。
    ExpireIndex::iterator expire_it; // entry 在到期时间索引的iterator
    PositionIndex::iterator position_it;
};
```

​

2）索引数据结构

主索引：主索引拥有 Entry 生命周期。

```cpp
using PrimaryIndex =
    std::unordered_map<BlockKey, std::unique_ptr<Entry>, BlockKeyHasher>;
```

到期时间索引：只保存 `Entry*` ，不拥有对象。用于快速找到全局最早过期的 entry：expire\_index.begin();&#x20;

```cpp
using ExpireIndex = std::multimap<uint64_t, Entry*>;

```

绝对位置索引：

```cpp
struct PositionKey {
    uint32_t abs_pos;
    uint64_t expire_at_ms;
};

struct PositionKeyLess {
    bool operator()(const PositionKey& a, const PositionKey& b) const
    {
        if (a.abs_pos != b.abs_pos) {
            return a.abs_pos < b.abs_pos;
        }
        return a.expire_at_ms < b.expire_at_ms;
    }
};

using PositionIndex = std::multimap<PositionKey, Entry*, PositionKeyLess>;
```

Entry结构体定义中的 `expire_it` 和 `position_it` 是 Entry 在到期时间、绝对位置索引里的准确位置，以便删除时可以直接通过 iterator 删除

MetadataIndex：

```cpp
class MetadataIndex {
private:
    mutable std::shared_mutex mu_; // 保护三套全局索引

    PrimaryIndex primary_index_;
    ExpireIndex expire_index_;
    PositionIndex position_index_;
};
```

#

# 5 整体流程

单线程task处理/多线程task处理待讨论

​

## 5.1 Dump流程

​[~https://excalidraw.com/#json=xYMvXtP9WOFdR7EtRuisP,O6T5BgfMCM5C7zmtSnspRQ~](https://excalidraw.com/#json=xYMvXtP9WOFdR7EtRuisP,O6T5BgfMCM5C7zmtSnspRQ)​

![](attachment/2.webp)

​

​

​

```cpp
  struct InflightRecord {
      TaskId task_id;
      Key key;
      uint64_t generation;

      TransportHandle handle;

      BufferHandle buffer;
      uint64_t submit_ms;
      uint64_t deadline_ms;

      enum class OpType {
          Dump,
          Load,
      } op_type;
  };
```

​

​
